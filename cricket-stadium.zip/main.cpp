#include <iostream>
using namespace std;

int main() {
    int length, breadth;

    // Read length and breadth from input
    cin >> length >> breadth;

    // Calculate perimeter (for rope)
    int ropeLength = 2 * (length + breadth);

    // Calculate area (for carpet)
    int carpetArea = length * breadth;

    // Print the results
    cout << ropeLength << endl;
    cout << carpetArea << endl;

    return 0;
}
