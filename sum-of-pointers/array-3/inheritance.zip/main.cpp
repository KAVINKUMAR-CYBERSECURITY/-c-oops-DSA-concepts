class Father {
    public:
    int cash=5000;//var
    void house(){//beh
    cout<<"father's house"<<endl;}
    private:
    int savings=50000;
    protected:
    void bike(){
        cout<<"Father's bike"<<endl;
    }
    
};
class child:Public Father{
    Public:
    int packet Money=1000;
    void mobile(){
        cout<<""
    }
}