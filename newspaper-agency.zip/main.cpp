#include<iostream>
using namespace std;
int main()
{
    int x,y,w;  //getting two integer input
     
     cin>>x>>y>>w;
     int numberof_copiessold=w*x;
     int price_percopy=w*y+100;
     int profit=numberof_copiessold-price_percopy;
     cout<<profit<<endl;
     return 0;
}